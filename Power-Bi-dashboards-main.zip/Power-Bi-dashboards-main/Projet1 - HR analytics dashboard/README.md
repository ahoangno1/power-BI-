This repository contains a Power Bi project:

- [Projet1 - HR analytics dashboard](https://github.com/imenbkr/Power-Bi-dashboards/tree/main/Projet1%20-%20HR%20analytics%20dashboard): A dashboard that displays HR data for a company, including Attrition count of Employees, Job Satisfaction rate, and Job Roles.
![HR-Analysis-Dashboard](https://user-images.githubusercontent.com/104791884/227393478-6a0d75ab-b6e8-41ef-8894-7ea529191153.jpg)
