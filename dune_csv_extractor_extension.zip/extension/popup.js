document.addEventListener('DOMContentLoaded', function() {
  const extractAllBtn = document.getElementById('extractAllBtn');
  const extractCurrentBtn = document.getElementById('extractCurrentBtn');
  const statusDiv = document.getElementById('status');

  // Hàm hiển thị trạng thái
  function showStatus(message) {
    statusDiv.textContent = message;
    statusDiv.style.display = 'block';
  }

  // Xử lý sự kiện khi nhấn nút "Tải dữ liệu từ tất cả các trang"
  extractAllBtn.addEventListener('click', function() {
    showStatus('Đang bắt đầu trích xuất dữ liệu từ tất cả các trang...');
    
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
      chrome.scripting.executeScript({
        target: {tabId: tabs[0].id},
        function: extractAllPagesData
      });
    });
  });

  // Xử lý sự kiện khi nhấn nút "Tải dữ liệu trang hiện tại"
  extractCurrentBtn.addEventListener('click', function() {
    showStatus('Đang trích xuất dữ liệu từ trang hiện tại...');
    
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
      chrome.scripting.executeScript({
        target: {tabId: tabs[0].id},
        function: extractCurrentPageData
      });
    });
  });

  // Lắng nghe thông báo từ content script
  chrome.runtime.onMessage.addListener(function(message) {
    if (message.status) {
      showStatus(message.status);
    }
  });
});

// Hàm trích xuất dữ liệu từ tất cả các trang
function extractAllPagesData() {
  // Thông báo cho popup biết đang bắt đầu
  chrome.runtime.sendMessage({status: 'Đang bắt đầu trích xuất dữ liệu từ tất cả các trang...'});
  
  // Gọi hàm trích xuất dữ liệu trong content.js
  window.postMessage({type: 'EXTRACT_ALL_PAGES'}, '*');
}

// Hàm trích xuất dữ liệu từ trang hiện tại
function extractCurrentPageData() {
  // Thông báo cho popup biết đang bắt đầu
  chrome.runtime.sendMessage({status: 'Đang trích xuất dữ liệu từ trang hiện tại...'});
  
  // Gọi hàm trích xuất dữ liệu trong content.js
  window.postMessage({type: 'EXTRACT_CURRENT_PAGE'}, '*');
}
