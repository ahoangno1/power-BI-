// Lắng nghe tin nhắn từ popup.js
window.addEventListener('message', function(event) {
  // Đảm bảo tin nhắn đến từ extension
  if (event.source !== window) return;
  
  if (event.data.type === 'EXTRACT_ALL_PAGES') {
    extractAllPagesToCSV();
  } else if (event.data.type === 'EXTRACT_CURRENT_PAGE') {
    extractCurrentPageToCSV();
  }
});

// Hàm gửi thông báo trạng thái đến popup
function sendStatusToPopup(message) {
  chrome.runtime.sendMessage({status: message});
  
  // Hiển thị thông báo trạng thái trên trang
  showStatus(message);
}

// Hàm xử lý ký tự đặc biệt
function escapeCSV(str) {
  if (typeof str !== 'string') {
    return '';
  }
  return str.replace(/"/g, '""').replace(/[\n\r]+/g, ' ');
}

// Hàm bọc giá trị trong dấu ngoặc kép
function quoteCSV(str) {
  if (typeof str !== 'string') {
    return '""';
  }
  return `"${escapeCSV(str)}"`;
}

// Hàm chờ phần tử xuất hiện
function waitForElement(selector, action, interval, timeout) {
  return new Promise(resolve => {
    const checkInterval = setInterval(() => {
      const element = document.querySelector(selector);
      if (element && element.offsetParent) {
        clearInterval(checkInterval);
        action(element);
        resolve(true);
      }
    }, interval);
    setTimeout(() => {
      clearInterval(checkInterval);
      resolve(false);
    }, timeout);
  });
}

// Hàm hiển thị thông báo trạng thái
function showStatus(message) {
  // Kiểm tra xem đã có thông báo chưa
  let statusDiv = document.getElementById('dune-extractor-status');
  if (!statusDiv) {
    // Tạo div thông báo
    statusDiv = document.createElement('div');
    statusDiv.id = 'dune-extractor-status';
    statusDiv.style.position = 'fixed';
    statusDiv.style.bottom = '20px';
    statusDiv.style.right = '20px';
    statusDiv.style.zIndex = '10000';
    statusDiv.style.backgroundColor = '#333';
    statusDiv.style.color = 'white';
    statusDiv.style.padding = '10px 15px';
    statusDiv.style.borderRadius = '4px';
    statusDiv.style.boxShadow = '0 2px 10px rgba(0, 0, 0, 0.2)';
    statusDiv.style.fontFamily = 'Arial, sans-serif';
    statusDiv.style.fontSize = '14px';
    document.body.appendChild(statusDiv);
  }
  
  // Cập nhật nội dung
  statusDiv.textContent = message;
  
  // Tự động xóa sau 5 giây nếu là thông báo hoàn thành
  if (message.includes('hoàn thành') || message.includes('lỗi')) {
    setTimeout(() => {
      if (document.body.contains(statusDiv)) {
        document.body.removeChild(statusDiv);
      }
    }, 5000);
  }
}

// Hàm trích xuất dữ liệu từ trang hiện tại
function extractCurrentPageToCSV() {
  try {
    // Tìm bảng
    const table = document.querySelector('.table_table__FDV2P');
    if (!table) {
      sendStatusToPopup('Lỗi: Không tìm thấy bảng!');
      return;
    }

    // Lấy tiêu đề cột
    const headers = table.querySelectorAll('thead th button');
    const csvRows = [Array.from(headers).map(h => quoteCSV(h.textContent.trim())).join(',')];

    // Lấy dữ liệu hàng
    const rows = table.querySelectorAll('tbody tr');
    rows.forEach(row => {
      const cells = row.querySelectorAll('td');
      let rowData = '';
      cells.forEach(cell => {
        const content = cell.querySelector('div:not(.visual_empty__uR3Nb)') || cell;
        rowData += quoteCSV(content.textContent.trim()) + ',';
      });
      csvRows.push(rowData.slice(0, -1)); // Bỏ dấu phẩy cuối
    });

    // Tạo file CSV
    const csvContent = csvRows.join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'dune_current_page_data_' + Date.now() + '.csv';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    sendStatusToPopup('Đã tải xuống dữ liệu trang hiện tại!');
  } catch (error) {
    sendStatusToPopup('Lỗi: ' + error.message);
  }
}

// Hàm chính lấy và gộp dữ liệu từ tất cả các trang
async function extractAllPagesToCSV() {
  try {
    // Selector chính xác cho nút Next
    const nextButtonSelector = '#results > div > div.SectionResults_results__vPGZw.Layout_results__3PJ5z > div > div.visual_vizFooter__vCe59 > ul > li:nth-child(6) > button';
    const checkInterval = 1000; // Kiểm tra mỗi 1s
    const timeout = 30000; // Chờ tối đa 30s

    sendStatusToPopup('Đang bắt đầu trích xuất dữ liệu từ tất cả các trang...');

    // Tìm bảng đầu tiên
    const table = document.querySelector('.table_table__FDV2P');
    if (!table) {
      sendStatusToPopup('Lỗi: Không tìm thấy bảng!');
      return;
    }

    // Lấy tiêu đề cột
    const headers = table.querySelectorAll('thead th button');
    const csvRows = [Array.from(headers).map(h => quoteCSV(h.textContent.trim())).join(',')];
    
    let pageCount = 1;
    let rowCount = 0;

    // Lặp qua các trang
    let hasNextPage = true;
    do {
      sendStatusToPopup(`Đang trích xuất dữ liệu từ trang ${pageCount}...`);
      
      // Lấy bảng hiện tại
      const currentTable = document.querySelector('.table_table__FDV2P');
      if (!currentTable) {
        sendStatusToPopup('Lỗi: Không tìm thấy bảng!');
        break;
      }

      // Lấy dữ liệu hàng
      const rows = currentTable.querySelectorAll('tbody tr');
      rows.forEach(row => {
        const cells = row.querySelectorAll('td');
        let rowData = '';
        cells.forEach(cell => {
          const content = cell.querySelector('div:not(.visual_empty__uR3Nb)') || cell;
          rowData += quoteCSV(content.textContent.trim()) + ',';
        });
        csvRows.push(rowData.slice(0, -1)); // Bỏ dấu phẩy cuối
        rowCount++;
      });

      // Kiểm tra trạng thái nút Next
      const nextButton = document.querySelector(nextButtonSelector);
      if (!nextButton || nextButton.hasAttribute('disabled') || nextButton.getAttribute('aria-disabled') === 'true') {
        hasNextPage = false;
        sendStatusToPopup('Đã hoàn thành việc trích xuất dữ liệu. Đang tạo file CSV...');
        
        // Tạo file CSV
        const csvContent = csvRows.join('\n');
        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'dune_all_pages_data_' + Date.now() + '.csv';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        
        sendStatusToPopup(`Đã hoàn thành! Đã tải xuống ${rowCount} dòng dữ liệu từ ${pageCount} trang.`);
      } else {
        // Chờ và nhấn nút Next
        sendStatusToPopup(`Đã trích xuất trang ${pageCount}. Đang chuyển sang trang tiếp theo...`);
        hasNextPage = await waitForElement(nextButtonSelector, btn => btn.click(), checkInterval, timeout);
        if (hasNextPage) {
          // Chờ để trang mới tải
          await new Promise(resolve => setTimeout(resolve, 2000));
          pageCount++;
        } else {
          sendStatusToPopup('Không thể chuyển sang trang tiếp theo. Đang tạo file CSV...');
        }
      }
    } while (hasNextPage);
    
  } catch (error) {
    sendStatusToPopup('Lỗi: ' + error.message);
  }
}
